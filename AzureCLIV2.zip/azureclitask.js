"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const fs = require("fs");
const Utility_1 = require("./src/Utility");
const ScriptType_1 = require("./src/ScriptType");
const FAIL_ON_STDERR = "FAIL_ON_STDERR";
class azureclitask {
    static runMain() {
        return __awaiter(this, void 0, void 0, function* () {
            var toolExecutionError = null;
            var exitCode = 0;
            try {
                var scriptType = ScriptType_1.ScriptTypeFactory.getSriptType();
                var tool = yield scriptType.getTool();
                var cwd = tl.getPathInput("cwd", true, false);
                if (tl.getInput("scriptLocation", true).toLowerCase() === "scriptPath" && !tl.filePathSupplied("cwd")) {
                    cwd = path.dirname(tl.getPathInput("scriptPath", true, true));
                }
                // determines whether output to stderr will fail a task.
                // some tools write progress and other warnings to stderr.  scripts can also redirect.
                var failOnStdErr = tl.getBoolInput("failOnStandardError", false);
                tl.mkdirP(cwd);
                tl.cd(cwd);
                Utility_1.Utility.throwIfError(tl.execSync("az", "--version"));
                // set az cli config dir
                this.setConfigDirectory();
                this.setAzureCloudBasedOnServiceEndpoint();
                var connectedService = tl.getInput("connectedServiceNameARM", true);
                this.loginAzureRM(connectedService);
                let errLinesCount = 0;
                let aggregatedErrorLines = [];
                tool.on('errline', (errorLine) => {
                    if (errLinesCount < 10) {
                        aggregatedErrorLines.push(errorLine);
                    }
                    errLinesCount++;
                });
                var addSpnToEnvironment = tl.getBoolInput("addSpnToEnvironment", false);
                if (!!addSpnToEnvironment && tl.getEndpointAuthorizationScheme(connectedService, true).toLowerCase() == "serviceprincipal") {
                    exitCode = yield tool.exec({
                        failOnStdErr: false,
                        ignoreReturnCode: true,
                        env: Object.assign({}, process.env, { servicePrincipalId: this.servicePrincipalId, servicePrincipalKey: this.servicePrincipalKey, tenantId: this.tenantId })
                    });
                }
                else {
                    exitCode = yield tool.exec({
                        failOnStdErr: false,
                        ignoreReturnCode: true
                    });
                }
                if (failOnStdErr && aggregatedErrorLines.length > 0) {
                    let error = FAIL_ON_STDERR;
                    aggregatedErrorLines.forEach((err) => {
                        tl.error(err);
                    });
                    throw error;
                }
            }
            catch (err) {
                toolExecutionError = err;
                if (err.stderr) {
                    toolExecutionError = err.stderr;
                }
            }
            finally {
                if (scriptType) {
                    yield scriptType.cleanUp();
                }
                if (this.cliPasswordPath) {
                    tl.debug('Removing spn certificate file');
                    tl.rmRF(this.cliPasswordPath);
                }
                //set the task result to either succeeded or failed based on error was thrown or not
                if (toolExecutionError === FAIL_ON_STDERR) {
                    tl.setResult(tl.TaskResult.Failed, tl.loc("ScriptFailedStdErr"));
                }
                else if (toolExecutionError) {
                    tl.setResult(tl.TaskResult.Failed, tl.loc("ScriptFailed", toolExecutionError));
                }
                else if (exitCode != 0) {
                    tl.setResult(tl.TaskResult.Failed, tl.loc("ScriptFailedWithExitCode", exitCode));
                }
                else {
                    tl.setResult(tl.TaskResult.Succeeded, tl.loc("ScriptReturnCode", 0));
                }
                //Logout of Azure if logged in
                if (this.isLoggedIn) {
                    this.logoutAzure();
                }
            }
        });
    }
    static loginAzureRM(connectedService) {
        var authScheme = tl.getEndpointAuthorizationScheme(connectedService, true);
        var subscriptionID = tl.getEndpointDataParameter(connectedService, "SubscriptionID", true);
        if (authScheme.toLowerCase() == "serviceprincipal") {
            let authType = tl.getEndpointAuthorizationParameter(connectedService, 'authenticationType', true);
            let cliPassword = null;
            var servicePrincipalId = tl.getEndpointAuthorizationParameter(connectedService, "serviceprincipalid", false);
            var tenantId = tl.getEndpointAuthorizationParameter(connectedService, "tenantid", false);
            this.servicePrincipalId = servicePrincipalId;
            this.tenantId = tenantId;
            if (authType == "spnCertificate") {
                tl.debug('certificate based endpoint');
                let certificateContent = tl.getEndpointAuthorizationParameter(connectedService, "servicePrincipalCertificate", false);
                cliPassword = path.join(tl.getVariable('Agent.TempDirectory') || tl.getVariable('system.DefaultWorkingDirectory'), 'spnCert.pem');
                fs.writeFileSync(cliPassword, certificateContent);
                this.cliPasswordPath = cliPassword;
            }
            else {
                tl.debug('key based endpoint');
                cliPassword = tl.getEndpointAuthorizationParameter(connectedService, "serviceprincipalkey", false);
                this.servicePrincipalKey = cliPassword;
            }
            let escapedCliPassword = cliPassword.replace(/"/g, '\\"');
            tl.setSecret(escapedCliPassword.replace(/\\/g, '\"'));
            //login using svn
            Utility_1.Utility.throwIfError(tl.execSync("az", `login --service-principal -u "${servicePrincipalId}" --password="${escapedCliPassword}" --tenant "${tenantId}" --allow-no-subscriptions`), tl.loc("LoginFailed"));
        }
        else if (authScheme.toLowerCase() == "managedserviceidentity") {
            //login using msi
            Utility_1.Utility.throwIfError(tl.execSync("az", "login --identity"), tl.loc("MSILoginFailed"));
        }
        else {
            throw tl.loc('AuthSchemeNotSupported', authScheme);
        }
        this.isLoggedIn = true;
        if (!!subscriptionID) {
            //set the subscription imported to the current subscription
            Utility_1.Utility.throwIfError(tl.execSync("az", "account set --subscription \"" + subscriptionID + "\""), tl.loc("ErrorInSettingUpSubscription"));
        }
    }
    static setConfigDirectory() {
        if (tl.getBoolInput("useGlobalConfig")) {
            return;
        }
        if (!!tl.getVariable('Agent.TempDirectory')) {
            var azCliConfigPath = path.join(tl.getVariable('Agent.TempDirectory'), ".azclitask");
            console.log(tl.loc('SettingAzureConfigDir', azCliConfigPath));
            process.env['AZURE_CONFIG_DIR'] = azCliConfigPath;
        }
        else {
            console.warn(tl.loc('GlobalCliConfigAgentVersionWarning'));
        }
    }
    static setAzureCloudBasedOnServiceEndpoint() {
        var connectedService = tl.getInput("connectedServiceNameARM", true);
        var environment = tl.getEndpointDataParameter(connectedService, 'environment', true);
        if (!!environment) {
            console.log(tl.loc('SettingAzureCloud', environment));
            Utility_1.Utility.throwIfError(tl.execSync("az", "cloud set -n " + environment));
        }
    }
    static logoutAzure() {
        try {
            tl.execSync("az", " account clear");
        }
        catch (err) {
            // task should not fail if logout doesn`t occur
            tl.warning(tl.loc("FailedToLogout"));
        }
    }
}
azureclitask.isLoggedIn = false;
azureclitask.cliPasswordPath = null;
azureclitask.servicePrincipalId = null;
azureclitask.servicePrincipalKey = null;
azureclitask.tenantId = null;
exports.azureclitask = azureclitask;
tl.setResourcePath(path.join(__dirname, "task.json"));
if (!Utility_1.Utility.checkIfAzurePythonSdkIsInstalled()) {
    tl.setResult(tl.TaskResult.Failed, tl.loc("AzureSDKNotFound"));
}
azureclitask.runMain();
